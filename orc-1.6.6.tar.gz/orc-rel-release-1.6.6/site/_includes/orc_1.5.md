The new features of ORC 1.5:

- [ORC-179]({{site.jira}}/ORC-179) Add ORC C++ Writer
- [ORC-91]({{site.jira}}/ORC-91) Support for variable length blocks in HDFS.
- [ORC-199]({{site.jira}}/ORC-199) Implement a CSV to ORC converter
- [ORC-344]({{site.jira}}/ORC-344) Support for using Decimal64ColumnVector
- [ORC-345]({{site.jira}}/ORC-345) Adding Decimal64StatisticsImpl
- [ORC-331]({{site.jira}}/ORC-331) Support for building C++ under MSVC.
- [ORC-234]({{site.jira}}/ORC-234) Support for older versions of Hadoop (>= 2.2.x)
- [ORC-305]({{site.jira}}/ORC-305) Added statistics for size on disk
