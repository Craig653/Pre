---
layout: news_item
title: "ORC adds 7 committers"
date: "2015-05-11 17:23:00 -0800"
author: omalley
categories: [team]
---

The ORC project management committee today added seven new committers
for their work on ORC. Welcome all!

* Gunther Hagleitner
* Aliaksei Sandryhaila
* Sergey Shelukhin
* Gopal Vijayaraghavan
* Stephen Walkauskas
* Kevin Wilfong
* Xuefu Zhang
