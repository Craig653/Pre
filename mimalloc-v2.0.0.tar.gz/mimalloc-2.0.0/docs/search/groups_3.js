var searchData=
[
  ['extended_20functions',['Extended Functions',['../group__extended.html',1,'']]]
];
